#!/usr/bin/env python3
"""A gramática GBNF aceita todos os exemplos e rejeita programas malformados."""
import glob, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from gbnf import accepts, parse_grammar

root = os.path.dirname(HERE)
rules = parse_grammar(open(os.path.join(root, "spec", "prova.gbnf"), encoding="utf-8").read())

bad_files = []
for f in sorted(glob.glob(os.path.join(root, "examples", "*.prova"))):
    text = open(f, encoding="utf-8").read()
    if not accepts(rules, text):
        bad_files.append(os.path.basename(f))
assert not bad_files, f"gramática rejeita exemplos válidos: {bad_files}"

OK = "(fn f (params (x i64)) (returns i64) (pre) (post) (body (return x)))\n"
assert accepts(rules, OK)
REJECT = {
    "sem post": "(fn f (params) (returns unit) (pre) (body))\n",
    "while sem decreases": "(fn f (params) (returns unit) (pre) (post) (body (while (< 1 2) (invariant))))\n",
    "operador inexistente": "(fn f (params (x i64)) (returns i64) (pre) (post) (body (return (^ x 1))))\n",
    "tipo inexistente": "(fn f (params (x f32)) (returns unit) (pre) (post) (body))\n",
    "parêntese faltando": "(fn f (params) (returns unit) (pre) (post) (body)\n",
    "instrução inexistente": "(fn f (params) (returns unit) (pre) (post) (body (goto 1)))\n",
    "identificador maiúsculo": "(fn F (params) (returns unit) (pre) (post) (body))\n",
}
for name, src in REJECT.items():
    assert not accepts(rules, src), f"gramática aceitou programa inválido: {name}"
print(f"gramática OK: {len(glob.glob(os.path.join(root, 'examples', '*.prova')))} exemplos aceitos, {len(REJECT)} inválidos rejeitados")
